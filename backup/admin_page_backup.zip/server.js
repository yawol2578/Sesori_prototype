require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const jwt = require("jsonwebtoken"); // ✅ 추가

const { setupWebSocket } = require("./websocket");
const authRoutes = require("./auth");
const reviewRoutes = require("./reviews");
const mealRoutes = require("./meals");
const { initDB } = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'; // ✅ 추가

setupWebSocket();
initDB();

app.use(cors());
app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

app.use("/", authRoutes);
app.use("/reviews", reviewRoutes);
app.use("/api", mealRoutes);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🚀 Server running on http://null4u.net:${PORT}`);
});